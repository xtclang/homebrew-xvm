This is the system repository for the XDK. Modules in
this directory are automatically loadable as necessary
by the command line tools.